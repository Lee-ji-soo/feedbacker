import Header from './Header';
import Feed from './Feed';
import About from './About';

export { Header, Feed, About }
