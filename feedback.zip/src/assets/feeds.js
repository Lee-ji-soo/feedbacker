const feeds = [
    {
        title: 'Engineered Garments Khaki Ripstop UL Backpack',
        src: 'https://img.ssensemedia.com/image/upload/b_white/c_scale,h_820/f_auto,dpr_2.0/202175M166065_1.jpg',
        from: 'SSENSE 공식홈페이지',
        content: 'Nylon ripstop backpack in khaki. Trim in black throughout. Webbing carry handle at top. Twin adjustable padded shoulder straps. Zippered pocket and textile logo patch in black at face. Foldover flap featuring press-release fastening. Patch pocket featuring bungee-style drawstring at sides.'
    },
    {
        title: 'The Elder-Statesman MED RIB STRIPE MOON DRESS',
        src: 'https://cdn.shopify.com/s/files/1/2507/4572/products/200805_TES_0374_600x.jpg?v=1599699180',
        from: 'elder-statesman 공식홈페이지',
        content: '20FW The Elder-statesman의 캐시미어 원피스 $1,245.00 made in LosAngeles, California'
    },
]
export { feeds }
